#ifndef _COMMON
#define _COMMON

#include <string>
#include <vector>

using namespace std;

vector<string> splitString(const string& s, const string& c);
#endif
